#define rand	pan_rand
#if defined(HAS_CODE) && defined(VERBOSE)
	cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* PROC LightBulb */
	case 3: /* STATE 1 - embedded:51 - [signal?turnOnLight] (0:0:0 - 1) */
		reached[1][1] = 1;
		if (boq != now.signal) continue;
		if (q_len(now.signal) == 0) continue;

		XX=1;
		if (6 != qrecv(now.signal, 0, 0, 0)) continue;
		if (q_flds[((Q0 *)qptr(now.signal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
		;
		qrecv(now.signal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.signal);
		sprintf(simtmp, "%d", 6); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.signal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 4: /* STATE 2 - embedded:52 - [printf('The light is turning on\\n')] (0:4:1 - 1) */
		IfNotBlocked
		reached[1][2] = 1;
		Printf("The light is turning on\n");
		/* merge: light_turned_on = 1(4, 3, 4) */
		reached[1][3] = 1;
		(trpt+1)->bup.oval = ((int)light_turned_on);
		light_turned_on = 1;
#ifdef VAR_RANGES
		logval("light_turned_on", ((int)light_turned_on));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 5: /* STATE 4 - embedded:54 - [signal!lightOn] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][4] = 1;
		if (q_len(now.signal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", now.signal);
		sprintf(simtmp, "%d", 5); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.signal, 0, 5, 1);
		{ boq = now.signal; };
		_m = 2; goto P999; /* 0 */
	case 6: /* STATE 7 - embedded:57 - [signal?changeColor] (0:0:0 - 1) */
		reached[1][7] = 1;
		if (boq != now.signal) continue;
		if (q_len(now.signal) == 0) continue;

		XX=1;
		if (4 != qrecv(now.signal, 0, 0, 0)) continue;
		if (q_flds[((Q0 *)qptr(now.signal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
		;
		qrecv(now.signal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.signal);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.signal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 7: /* STATE 8 - embedded:58 - [printf('Color is changing \\n')] (0:10:1 - 1) */
		IfNotBlocked
		reached[1][8] = 1;
		Printf("Color is changing \n");
		/* merge: color_changed = 1(10, 9, 10) */
		reached[1][9] = 1;
		(trpt+1)->bup.oval = ((int)color_changed);
		color_changed = 1;
#ifdef VAR_RANGES
		logval("color_changed", ((int)color_changed));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 8: /* STATE 10 - embedded:60 - [signal!colorChanged] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][10] = 1;
		if (q_len(now.signal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", now.signal);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.signal, 0, 3, 1);
		{ boq = now.signal; };
		_m = 2; goto P999; /* 0 */
	case 9: /* STATE 13 - embedded:63 - [signal?turnOffLight] (0:0:0 - 1) */
		reached[1][13] = 1;
		if (boq != now.signal) continue;
		if (q_len(now.signal) == 0) continue;

		XX=1;
		if (2 != qrecv(now.signal, 0, 0, 0)) continue;
		if (q_flds[((Q0 *)qptr(now.signal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
		;
		qrecv(now.signal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.signal);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.signal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 10: /* STATE 14 - embedded:64 - [printf('Light is turning off \\n')] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][14] = 1;
		Printf("Light is turning off \n");
		_m = 3; goto P999; /* 0 */
	case 11: /* STATE 15 - embedded:65 - [signal!lightOff] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][15] = 1;
		if (q_len(now.signal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", now.signal);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.signal, 0, 1, 1);
		{ boq = now.signal; };
		_m = 2; goto P999; /* 0 */
	case 12: /* STATE 16 - embedded:66 - [light_turned_off = 1] (0:22:1 - 1) */
		IfNotBlocked
		reached[1][16] = 1;
		(trpt+1)->bup.oval = ((int)light_turned_off);
		light_turned_off = 1;
#ifdef VAR_RANGES
		logval("light_turned_off", ((int)light_turned_off));
#endif
		;
		/* merge: goto commandsRun(22, 17, 22) */
		reached[1][17] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 13: /* STATE 21 - embedded:72 - [no_errors = 1] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][21] = 1;
		(trpt+1)->bup.oval = ((int)no_errors);
		no_errors = 1;
#ifdef VAR_RANGES
		logval("no_errors", ((int)no_errors));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 14: /* STATE 23 - embedded:74 - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][23] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Raspberry */
	case 15: /* STATE 1 - embedded:20 - [printf('Raspberry sends a signal to turn on the light \\n')] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][1] = 1;
		Printf("Raspberry sends a signal to turn on the light \n");
		_m = 3; goto P999; /* 0 */
	case 16: /* STATE 2 - embedded:21 - [signal!turnOnLight] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][2] = 1;
		if (q_len(now.signal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", now.signal);
		sprintf(simtmp, "%d", 6); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.signal, 0, 6, 1);
		{ boq = now.signal; };
		_m = 2; goto P999; /* 0 */
	case 17: /* STATE 5 - embedded:27 - [signal?lightOn] (0:0:0 - 1) */
		reached[0][5] = 1;
		if (boq != now.signal) continue;
		if (q_len(now.signal) == 0) continue;

		XX=1;
		if (5 != qrecv(now.signal, 0, 0, 0)) continue;
		if (q_flds[((Q0 *)qptr(now.signal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
		;
		qrecv(now.signal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.signal);
		sprintf(simtmp, "%d", 5); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.signal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 18: /* STATE 6 - embedded:28 - [printf('Light is on\\n')] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][6] = 1;
		Printf("Light is on\n");
		_m = 3; goto P999; /* 0 */
	case 19: /* STATE 7 - embedded:29 - [signal!changeColor] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][7] = 1;
		if (q_len(now.signal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", now.signal);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.signal, 0, 4, 1);
		{ boq = now.signal; };
		_m = 2; goto P999; /* 0 */
	case 20: /* STATE 10 - embedded:32 - [signal?colorChanged] (0:0:0 - 1) */
		reached[0][10] = 1;
		if (boq != now.signal) continue;
		if (q_len(now.signal) == 0) continue;

		XX=1;
		if (3 != qrecv(now.signal, 0, 0, 0)) continue;
		if (q_flds[((Q0 *)qptr(now.signal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
		;
		qrecv(now.signal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.signal);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.signal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 21: /* STATE 11 - embedded:33 - [printf('Color has been changed \\n')] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][11] = 1;
		Printf("Color has been changed \n");
		_m = 3; goto P999; /* 0 */
	case 22: /* STATE 12 - embedded:34 - [signal!turnOffLight] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][12] = 1;
		if (q_len(now.signal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", now.signal);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.signal, 0, 2, 1);
		{ boq = now.signal; };
		_m = 2; goto P999; /* 0 */
	case 23: /* STATE 15 - embedded:37 - [signal?lightOff] (0:0:0 - 1) */
		reached[0][15] = 1;
		if (boq != now.signal) continue;
		if (q_len(now.signal) == 0) continue;

		XX=1;
		if (1 != qrecv(now.signal, 0, 0, 0)) continue;
		if (q_flds[((Q0 *)qptr(now.signal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
		;
		qrecv(now.signal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.signal);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.signal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 24: /* STATE 16 - embedded:38 - [printf('Light off \\n')] (0:22:0 - 1) */
		IfNotBlocked
		reached[0][16] = 1;
		Printf("Light off \n");
		/* merge: goto commandsRun(22, 17, 22) */
		reached[0][17] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 25: /* STATE 21 - embedded:44 - [no_errors = 1] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][21] = 1;
		(trpt+1)->bup.oval = ((int)no_errors);
		no_errors = 1;
#ifdef VAR_RANGES
		logval("no_errors", ((int)no_errors));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 26: /* STATE 23 - embedded:46 - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][23] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

